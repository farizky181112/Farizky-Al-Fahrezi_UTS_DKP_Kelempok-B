# Data Inti
data_snr = [5, 8, 11, 14, 18, 22, 27, 9, 16, 24, 12, 30, 7, 20, 15]

# Data Tambahan
data_tambahan = [0, 9.9, 10, 19.9, 35]

# data gabungan
data_gabungan = data_snr + data_tambahan

# fungsi menentukan kualitas sinyal berdasarkan SNR
def kualitas_sinyal(snr):
    if snr < 10:
        return "RENDAH"
    elif 10 <= snr < 20: 
        return "BAIK"
    else:
        return "SANGAT BAIK"

# Fungsi menghitung kategori kualitas sinyal
def menghitung_kategori(data):
    rendah = 0
    baik = 0
    sangat_baik = 0

    # Periksa setiap data
    for snr in data:
        status = kualitas_sinyal(snr)

        if status == "RENDAH":
            rendah += 1
        elif status == "BAIK":
            baik += 1
        else:
            sangat_baik += 1

    return rendah, baik, sangat_baik

# memanggil fungsi
hasil = menghitung_kategori(data_gabungan)
print("jumlah sinyal RENDAH:", hasil[0])
print("jumlah sinyal BAIK:", hasil[1])
print("jumlah sinyal SANGAT BAIK:", hasil[2])

#funsi mengjhitung rata-rata SNR
def rata_rata_snr(data):
    total = sum(data)
    jumlah_data = len(data)
    rata_rata = total / jumlah_data
    return rata_rata

# memanggil fungsi rata_rata_snr
rata_rata = rata_rata_snr(data_gabungan)
print("Rata-rata SNR:", rata_rata)
print("total data:", len(data_gabungan))

# menampilkan kualitas setiap data
for nomor, snr in enumerate(data_gabungan, start=1):
    status = kualitas_sinyal(snr)
    print(f"{nomor:02d}. SNR: {snr} dB -> {status}")
    
# mencari nilai maksimum dan minimum 
nilai_maksimum = max(data_gabungan)
nilai_minimum = min(data_gabungan)
print("SNR Maksimum:", nilai_maksimum, "dB")
print("SNR Minimum:", nilai_minimum, "dB")

# FUNGSI UNTUK MENGUJI KUALITAS SINYAL
def uji_snr(nomor, nilai, expected):
    actual = kualitas_sinyal(nilai)

    if actual == expected:
        hasil_uji = "PASS"
    else:
        hasil_uji = "FAIL"

    print(f"\nTest {nomor}")
    print("Input    :", nilai, "dB")
    print("Expected :", expected)
    print("Actual   :", actual)
    print("Hasil    :", hasil_uji)

    return hasil_uji


# TESTING WAJIB 
print("\n================================")
print("         TESTING WAJIB")
print("================================")

daftar_test = [
    (1, 9, "RENDAH"),
    (2, 10, "BAIK"),
    (3, 11, "BAIK"),
    (4, 19, "BAIK"),
    (5, 20, "SANGAT BAIK"),
    (6, 21, "SANGAT BAIK"),
    (7, 0, "RENDAH"),
    (8, 35, "SANGAT BAIK")
]

jumlah_pass = 0
jumlah_fail = 0

for nomor, nilai, expected in daftar_test:
    hasil_uji = uji_snr(nomor, nilai, expected)

    if hasil_uji == "PASS":
        jumlah_pass += 1
    else:
        jumlah_fail += 1


# RINGKASAN HASIL TESTING
print("\n================================")
print("       HASIL AKHIR TESTING")
print("================================")

print("Total pengujian :", len(daftar_test))
print("PASS            :", jumlah_pass)
print("FAIL            :", jumlah_fail)

if jumlah_fail == 0:
    print("STATUS: SEMUA PENGUJIAN BERHASIL")
else:
    print("STATUS: ADA PENGUJIAN GAGAL")


